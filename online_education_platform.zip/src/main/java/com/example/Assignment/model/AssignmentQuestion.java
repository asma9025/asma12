package com.example.Assignment.model;

import jakarta.persistence.*;

@Entity
@Table(name="assignment_questions")
public class AssignmentQuestion {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "assignquestionId")
    private int assignquestionId;
    private int assignment_id;
    private String question;

    public AssignmentQuestion() {}

    public int getAssignQuestionId() {
        return assignquestionId;
    }

    public void setAssignQuestionId(int assignQuestionId) {
        this.assignquestionId = assignQuestionId;
    }

    public int getAssignment_id() {
        return assignment_id;
    }

    public void setAssignment_id(int assignment_id) {
        this.assignment_id = assignment_id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}

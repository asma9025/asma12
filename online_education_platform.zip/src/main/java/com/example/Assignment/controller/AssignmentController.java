package com.example.Assignment.controller;

import java.util.List;
import java.util.UUID;
import org.springframework.web.bind.annotation.*;
import com.example.Assignment.dto.AssignmentResponse;
import com.example.Assignment.model.AssignmentQuestion;
import com.example.Assignment.model.AssignmentSubmission;
import com.example.Assignment.service.AssignmentService;

@RestController
@RequestMapping("/assignment")
public class AssignmentController {
    private final AssignmentService assignmentService;

    public AssignmentController(AssignmentService assignmentService) {
        this.assignmentService = assignmentService;
    }

    @PostMapping("/questions")
    public AssignmentQuestion addQuestion(@RequestBody AssignmentResponse questionDto) {
        return assignmentService.addQuestion(questionDto);
    }

    @GetMapping("/questions")
    public List<AssignmentQuestion> getAllQuestions() {
        return assignmentService.getAllQuestions();
    }

    @PostMapping("/submit")
    public AssignmentSubmission submitAssignment(@RequestBody AssignmentResponse submissionDto) {
        return assignmentService.submitAssignment(submissionDto);
    }

    @GetMapping("/submissions")
    public List<AssignmentSubmission> getAllSubmissions() {
        return assignmentService.getAllSubmissions();
    }

    @GetMapping("/submission/{id}")
    public AssignmentSubmission getSubmissionById(@PathVariable UUID id) {
        return assignmentService.getSubmissionById(id);
    }
}

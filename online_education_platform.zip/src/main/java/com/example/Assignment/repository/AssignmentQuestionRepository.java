package com.example.Assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.Assignment.model.AssignmentQuestion;

@Repository
public interface AssignmentQuestionRepository extends JpaRepository<AssignmentQuestion, Integer> {
}

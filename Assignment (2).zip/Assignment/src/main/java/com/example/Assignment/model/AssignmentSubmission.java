package com.example.Assignment.model;
import java.sql.Date;

import jakarta.persistence.*;


@Entity
@Table(name="assignment_submission")
public class AssignmentSubmission {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int submission_id;
	private long user_id;
	private int assignment_id;
	@Lob
	private long[] answer_upload;
	private int obtained_marks;

	private Date submittedAt;
	
	

	public AssignmentSubmission() {}

	public int getSubmission_id() {
		return submission_id;
	}

	public void setSubmission_id(int submission_id) {
		this.submission_id = submission_id;
	}

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	public int getAssignment_id() {
		return assignment_id;
	}

	public void setAssignment_id(int assignment_id) {
		this.assignment_id = assignment_id;
	}

	public long[] getAnswer_upload() {
		return answer_upload;
	}

	public void setAnswerUpload(long[] answer_upload) {
		this.answer_upload = answer_upload;
	}

	public int getObtained_marks() {
		return obtained_marks;
	}

	public void setObtained_marks(int obtained_marks) {
		this.obtained_marks = obtained_marks;
	}

	public Date getSubmittedAt() {
		return submittedAt;
	}

	public void setSubmittedAt(Date submittedAt) {
		this.submittedAt = submittedAt;
	}
	
	
	

}

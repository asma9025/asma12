package com.example.Assignment.dto;

public class AssignmentResponse {
	
	private int assignment_id;
	private String question;
	private long user_id;
	private long[] answer_upload;
	private int obtained_marks;
	private int assignquestionId;
	public int getAssignquestionId() {
		return assignquestionId;
	}
	public void setAssignquestionId(int assignQuestionId) {
		this.assignquestionId = assignQuestionId;
	}
	public int getAssignment_id() {
		return assignment_id;
	}
	public void setAssignment_id(int assignment_id) {
		this.assignment_id = assignment_id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public long getUser_id() {
		return user_id;
	}
	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}
	public long[] getAnswer_upload() {
		return answer_upload;
	}
	public void setAnswer_upload(long[] answer_upload) {
		this.answer_upload = answer_upload;
	}
	public int getObtained_marks() {
		return obtained_marks;
	}
	public void setObtained_marks(int obtained_marks) {
		this.obtained_marks = obtained_marks;
	}
}
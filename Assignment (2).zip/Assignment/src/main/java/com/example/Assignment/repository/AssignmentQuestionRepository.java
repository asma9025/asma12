package com.example.Assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Assignment.model.AssignmentQuestion;

public interface AssignmentQuestionRepository extends JpaRepository<AssignmentQuestion,Integer>
{
	
}
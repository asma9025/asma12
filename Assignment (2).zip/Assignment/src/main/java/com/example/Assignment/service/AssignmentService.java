package com.example.Assignment.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.Assignment.dto.AssignmentResponse;
import com.example.Assignment.model.AssignmentQuestion;
import com.example.Assignment.model.AssignmentSubmission;
import com.example.Assignment.repository.AssignmentQuestionRepository;
import com.example.Assignment.repository.AssignmentSubmissionRepository;

@Service
public class AssignmentService {
	private final AssignmentQuestionRepository questionRepo ;
	private final AssignmentSubmissionRepository submissionRepo;
	public AssignmentService(AssignmentQuestionRepository questionRepo, AssignmentSubmissionRepository submissionRepo) {
		super();
		this.questionRepo = questionRepo;
		this.submissionRepo = submissionRepo;
	}
	public AssignmentQuestion addQuestion(AssignmentResponse questionDto)
	{
		AssignmentQuestion question=new AssignmentQuestion();
		question.setAssignQuestionId(questionDto.getAssignquestionId());
		question.setAssignment_id(questionDto.getAssignment_id());
		question.setQuestion(questionDto.getQuestion());
		return questionRepo.save(question);
		
	}
	public List<AssignmentQuestion>getAllQuestions(){
		return questionRepo.findAll();
		
	}
	public AssignmentSubmission submitAssignment(AssignmentResponse submissionDto)
	{
		AssignmentSubmission submission=new AssignmentSubmission();
		submission.setUser_id(submissionDto.getUser_id());
		submission.setAssignment_id(submissionDto.getAssignment_id());
		submission.setObtained_marks(submissionDto.getObtained_marks());
		return submissionRepo.save(submission);
		
	}
	public List<AssignmentSubmission>getAllSubmissions()
	{
		return submissionRepo.findAll();
	}
	
	
}

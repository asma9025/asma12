package com.example.AssignmentModule.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;
import com.example.AssignmentModule.entity.Submission;

import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;

@Repository
public interface SubmissionDao extends JpaRepository<Submission, UUID> {
	
	Submission findByUserIdAndAssignmentId(int userId, int assignmentId);
}
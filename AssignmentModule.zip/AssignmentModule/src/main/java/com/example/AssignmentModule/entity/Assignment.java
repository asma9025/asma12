package com.example.AssignmentModule.entity;

import java.time.LocalDateTime;
import java.util.*;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Assignment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable=false,unique=true)
    private int assignmentId;
    
    @Column(nullable=false)
    private int CourseId;
    
    @OneToMany(mappedBy="assignment")
    private Set<Submission> submissions=new HashSet<Submission>();
    @Column(nullable=false)
    private String Question;
    
    @Column(nullable=false)
    private int TotalMarks;
	private LocalDateTime createdAt;
	
	@Column(nullable = false)
	private LocalDateTime deadline;
    
    @PrePersist
    public void generateCreatedAt() {
        this.createdAt = LocalDateTime.now();
    }
	
}

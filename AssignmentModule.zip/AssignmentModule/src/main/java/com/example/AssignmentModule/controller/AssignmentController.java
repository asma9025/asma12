package com.example.AssignmentModule.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.AssignmentModule.entity.Assignment;
import com.example.AssignmentModule.entity.Submission;
import com.example.AssignmentModule.service.AssignmentService;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class AssignmentController {
    @Autowired
    private AssignmentService assignmentService;


    @GetMapping("/assignments")
    public List<Assignment> getAllAssignments() {
        return assignmentService.getAllAssignments();
    }

    @PostMapping("/assignments")
    public Assignment createAssignment(@RequestBody Assignment assignment) {
        return assignmentService.createAssignment(assignment);
    }

   
    @GetMapping("/submissions")
    public List<Submission> getAllSubmissions() {
        return assignmentService.getAllSubmissions();
    }

    @PostMapping("/submissions")
    public Submission createSubmission(@RequestBody Submission submission) {
        return assignmentService.createSubmission(submission);
    }
    
    @PostMapping("/upload")
    public void uploadSubmission(@RequestParam("file") MultipartFile file,
                                 @RequestParam("userId") int userId,
                                 @RequestParam("assignmentId") int assignmentId) throws IOException{
    	assignmentService.saveSubmission(file, userId, assignmentId);
    }
    
    @GetMapping("/{userId}/file/{assignmentId}")
    public void getFile(@PathVariable int userId, @PathVariable int assignmentId,HttpServletResponse response)throws IOException{
        byte[] file= assignmentService.getFileByUserIdAndAssignmentId(userId, assignmentId);
        response.setContentType("application/pdf");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=submission.pdf");
        response.getOutputStream().write(file);
    }
    
    @PutMapping("/user/{userId}/assignment/{assignmentId}/marks/{marks}")
    public void assignMarks(@PathVariable int userId, @PathVariable int assignmentId, @PathVariable int marks) {
    	assignmentService.assignMarksByUserId(userId, assignmentId, marks);
    }
}

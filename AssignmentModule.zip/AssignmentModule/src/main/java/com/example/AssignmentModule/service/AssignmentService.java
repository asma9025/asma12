package com.example.AssignmentModule.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.AssignmentModule.dao.AssignmentDao;
import com.example.AssignmentModule.dao.SubmissionDao;
import com.example.AssignmentModule.entity.Assignment;
import com.example.AssignmentModule.entity.Submission;

import java.io.IOException;
import java.util.List;

@Service
public class AssignmentService {
    @Autowired
    private AssignmentDao assignmentDao;

    @Autowired
    private SubmissionDao submissionDao;

   
    public List<Assignment> getAllAssignments() {
        return assignmentDao.findAll();
    }

    public Assignment createAssignment(Assignment assignment) {
        return assignmentDao.save(assignment);
    }

   
    public List<Submission> getAllSubmissions() {
        return submissionDao.findAll();
    }

    public Submission createSubmission(Submission submission) {
        return submissionDao.save(submission);
    }
    
    public void saveSubmission(MultipartFile file, int userId, int assignmentId)throws IOException {
        Submission submission = new Submission();
        submission.setUserId(userId);
        //submission.setAssignmentId(assignmentId);
        Assignment assignment = assignmentDao.findById(assignmentId).orElseThrow(() -> new IllegalArgumentException("Invalid assignment ID"));
        submission.setAssignment(assignment);
        submission.setAnswerUpload(file.getBytes());
        submissionDao.save(submission);
    }
    
    
    public byte[] getFileByUserIdAndAssignmentId(int userId, int assignmentId) {
        Submission submission = submissionDao.findByUserIdAndAssignmentId(userId, assignmentId);
        return submission != null ? submission.getAnswerUpload() : null;
    }
    
    public void assignMarksByUserId(int userId, int assignmentId, int marks) {
        Submission submission = submissionDao.findByUserIdAndAssignmentId(userId, assignmentId);
        if (submission != null) {
            submission.setObtainedMarks(marks);
            submissionDao.save(submission);
        }
    }
    
}

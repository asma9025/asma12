package com.example.AssignmentModule.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;


@Entity
public class Submission {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID  submissionId;
    
    @Column(nullable=false)
    private int userId;
    
    @ManyToOne
    @JoinColumn(name="assignmentId")
    private Assignment assignment;
    
    
    @Lob
    private byte[] answerUpload;
   
    private int obtainedMarks;
    
    //submission date
    @Column(nullable=false)
    private LocalDateTime submittedAt;
    public UUID getSubmissionId() {
        return submissionId;
    }
    
    public void setSubmissionId(UUID submissionId) {
        this.submissionId = submissionId;
    }
    
    
    public LocalDateTime getSubmittedAt() {
		return submittedAt;
	}
	public void setSubmittedAt(LocalDateTime submittedAt) {
		this.submittedAt = submittedAt;
	}
	//	public int getSubmissionId() {
//		return submissionId;
//	}
//	public void setSubmissionId(int submissionId) {
//		this.submissionId = submissionId;
//	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
//	public int getAssignmentId() {
//		return assignmentId;
//	}
//	public void setAssignmentId(int assignmentId) {
//		this.assignmentId = assignmentId;
//	}
	public byte[] getAnswerUpload() {
		return answerUpload;
	}
	public void setAnswerUpload(byte[] answerUpload) {
		this.answerUpload = answerUpload;
	}
	public int getObtainedMarks() {
		return obtainedMarks;
	}
	public void setObtainedMarks(int obtainedMarks) {
		this.obtainedMarks = obtainedMarks;
	}
	public void setAssignment(Assignment assignment) {
	        this.assignment = assignment;
	}
	
	

}
package com.example.AssignmentModule.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.AssignmentModule.entity.Assignment;

@Repository
public interface AssignmentDao extends JpaRepository<Assignment, Integer> {

}